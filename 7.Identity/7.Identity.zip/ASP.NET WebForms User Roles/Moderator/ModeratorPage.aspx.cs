﻿using ChatApp.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Error_Handler_Control;

namespace ChatApp.Moderator
{
    public partial class ModeratorPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Edit_Command(object sender, CommandEventArgs e)
        {

        }

        public void MessagesListView_InsertItem()
        {
            var item = new Message();
            TryUpdateModel(item);
            if (ModelState.IsValid)
            {
                // Save changes here

            }
        }

        // The id parameter name should match the DataKeyNames value set on the control
        public void MessagesListView_UpdateItem(int id)
        {
            using (var context = new MessagesEntities())
            {
                var message = context.Messages.Find(id);               
                if (message == null)
                {
                    ErrorSuccessNotifier.AddErrorMessage("No such message was found!");
                    return;
                }

                try
                {
                    TryUpdateModel(message);
                    if (ModelState.IsValid)
                    {
                        context.SaveChanges();
                    }
                }
                catch (Exception ex) 
                {
                    ErrorSuccessNotifier.AddErrorMessage(ex);
                }
            }
        }

        // The return type can be changed to IEnumerable, however to support
        // paging and sorting, the following parameters must be added:
        //     int maximumRows
        //     int startRowIndex
        //     out int totalRowCount
        //     string sortByExpression
        public IQueryable<ChatApp.Models.Message> MessagesListView_GetData()
        {
            var msgContext = new MessagesEntities();
            return msgContext.Messages;
        }
    }
}