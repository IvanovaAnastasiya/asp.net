﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using ChatApp.Models;

namespace ChatApp
{
    public partial class Chat : Page
    {
        protected void Page_PreRender(object sender, EventArgs e)
        {
            using (var msgContext = new MessagesEntities())
            {
                var messages = msgContext.Messages.ToList();
                this.Messages.DataSource = messages;
                this.Messages.DataBind();               
                
            }
        }

        protected void PostMessageButton_Click(object sender, EventArgs e)
        {
            Page.Validate();

            if (IsValid)
            {       
                using (var msgContext = new MessagesEntities())
                {
                    msgContext.Messages.Add(new Message() 
                    { 
                        Text = this.NewMessageTextBox.Text }
                    );
                    try
                    {
                        msgContext.SaveChanges();
                        this.NewMessageTextBox.Text = "";
                        this.NewMessageTextBox.Attributes["placeholder"] = "Message sent!";
                    }
                    catch (Exception ex)
                    {
                        Error_Handler_Control.ErrorSuccessNotifier.AddErrorMessage(ex);
                    }
                }
            }
           
        }
    }
}