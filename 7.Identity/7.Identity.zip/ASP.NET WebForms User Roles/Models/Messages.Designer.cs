﻿// Default code generation is disabled for model 'C:\Users\Георги\Desktop\download\downloads\AcademyDocuments\ASP.NET\Lectures\9. ASP.NET Membership\ASP.NET One Identity Demos\ASP.NET WebForms User Roles\Models\Messages.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.